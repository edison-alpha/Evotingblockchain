import { ExclamationTriangleIcon } from '@heroicons/react/20/solid'
import { useContext, useEffect, useState } from 'react';
import { AuthContext } from '../../context/AuthContext';

export default function CandidateDetails() {
  const { contract, provider, adminAccount, account } = useContext(AuthContext);
  if (account !== adminAccount) {
    return (
      <VoterComponent />
    )
  } else {
    return (
      <AdminComponent contract={contract} provider={provider} />
    )
  }
}

const AdminComponent = ({ contract, provider }) => {

  const [candidates, setCandidates] = useState();

  useEffect(() => {
    const getCandidates = async () => {
      try {
        const signer = contract.connect(provider.getSigner());
        const cand = await signer.getCandidate();
        console.log(cand); // Tambahkan log untuk memeriksa data
        setCandidates(cand);
      } catch (error) {
        console.log(error); // Log error jika ada
      }
    }
    getCandidates();
  }, [contract, provider]) // Added 'contract' and 'provider' to the dependency array

  return (
    <div className="px-4 sm:px-6 lg:px-8">
      <div className="sm:flex sm:items-center">
        <div className="sm:flex-auto">
          <h1 className="text-xl font-semibold text-gray-900">Nama Nama Candidat</h1>
          <p className="mt-2 text-sm text-gray-700">
            Di bawah ini merupakan nama-nama candidat yg meliputi foto, nama, jurusan, Nim, dan status
          </p>
        </div>

      </div>
      <div className="mt-8 flex flex-col">
        <div className="-my-2 -mx-4 overflow-x-auto sm:-mx-6 lg:-mx-8">
          <div className="inline-block min-w-full py-2 align-middle md:px-6 lg:px-8">
            <div className="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
              <table className="min-w-full divide-y divide-gray-300">
                <thead className="bg-blue-100">
                  <tr>
                    <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6">
                      Nama
                    </th>
                    <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                      Jurusan
                    </th>
                    <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                      Nim
                    </th>
                    <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                      Status
                    </th>
                    {/* <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                      Party Logo
                    </th> */}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200 bg-white">
                  {candidates?.map((item, i) => {
                    return (
                      <>
                        <tr key={i}>
                          <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm sm:pl-6">
                            <div className="flex items-center">
                              <div className="h-10 w-10 flex-shrink-0">
                                <img className="h-10 w-10 rounded-full" src={`https://gateway.pinata.cloud/ipfs/${item.candidate_img}`} alt="" />
                              </div>
                              <div className="ml-4">
                                <div className="font-medium text-gray-900">{item.candidate_name}</div>
                                {/* <div className="text-gray-500">{person.email}</div> */}
                              </div>
                            </div>
                          </td>
                          <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                            <div className="text-gray-900">{item.candidate_partyName}</div>

                          </td>
                          <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                            <div className="text-gray-500">{item.candidate_age.toNumber()}</div>
                          </td>
                          <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                            <span className="inline-flex rounded-full bg-blue-100 px-2 text-xs font-semibold leading-5 text-blue-800">
                              Active
                            </span>
                          </td>
                          {/* ///--------------PARTYLOGO-------------/// */}

                          {/* <td className="relative whitespace-nowrap py-4 pl-3 pr-4 text-right text-sm font-medium sm:pr-6">
                            <div className="h-10 w-10 flex-shrink-0">
                              <img className="h-10 w-10 rounded-full" src={`https://gateway.pinata.cloud/ipfs/${item.candidate_partyLogo}`} alt="" />
                            </div>
                          </td> */}
                        </tr>
                      </>
                    )
                  }
                  )}
                </tbody>
              </table>
            </div>
            {candidates?.length === 0 && <p className='mt-4 text-center'>Tidak ada Kandidat yang ter regristasi!!</p>} 
          </div>
        </div>
      </div>
    </div>
  )
}


const VoterComponent = () => {
  return (
    <div className="rounded-md bg-yellow-50 p-4">
      <div className="flex">
        <div className="flex-shrink-0">
          <ExclamationTriangleIcon className="h-5 w-5 text-yellow-400" aria-hidden="true" />
        </div>
        <div className="ml-3">
          <h3 className="text-sm font-semibold text-yellow-800">Panduan Voting</h3>
          <div className="mt-2 text-sm text-yellow-700">
            <p className='text-lg'>
              Selamat Datang
            </p>
            <h2>1. Instalasi Web3 Wallet yang Mendukung EVM</h2>
            <p>Pilih salah satu dompet berikut: MetaMask, OKX Wallet, atau TokenPocket.</p>
            <ul>
                <li><strong>MetaMask</strong>: Dapat diunduh sebagai ekstensi browser atau aplikasi mobile.</li>
                <li><strong>OKX Wallet</strong>: Tersedia dalam bentuk ekstensi browser atau aplikasi mobile.</li>
                <li><strong>TokenPocket</strong>: Bisa diunduh di Google Play atau App Store.</li>
            </ul>

            <h2>2. Buat Wallet dan Simpan Recovery Phrase</h2>
            <p>Setelah menginstal dompet, buatlah wallet baru. Simpan recovery phrase (frasa pemulihan) dengan aman, jangan pernah membagikannya ke siapa pun. Recovery phrase ini sangat penting untuk melindungi akses ke dompet Anda.</p>

            <h2>3. Salin Alamat Wallet</h2>
            <p>Setelah wallet dibuat, salin alamat wallet (public address) yang akan digunakan untuk bertransaksi di blockchain.</p>

            <h2>4. Klaim Faucet (Testnet)</h2>
            <p>Buka website faucet yang sesuai dengan jaringan testnet, misalnya Sepolia. Tempel alamat wallet Anda untuk mendapatkan token testnet yang akan digunakan untuk membayar gas fee saat bertransaksi.</p>

            <h2>5. Login ke Aplikasi Pemilihan</h2>
            <p>Buka aplikasi pemilihan di <strong>http://localhost:3000/</strong>. Login dengan memasukkan NIM dan password SIMTIK yang telah diberikan oleh kampus.</p>

            <h2>6. Hubungkan Wallet</h2>
            <p>Setelah login:</p>
            <ul>
                <li>Pilih opsi "Connect Wallet" untuk menghubungkan dompet Anda ke aplikasi.</li>
                <li>Dompet yang sudah terhubung akan digunakan untuk transaksi blockchain.</li>
            </ul>

            <h2>7. Mint Soulbound Token (SBT)</h2>
            <p>Kunjungi <strong>http://localhost:3000/</strong> untuk melakukan minting SBT. Setujui transaksi di dompet Anda untuk menerima SBT, yang berfungsi sebagai bukti identitas dalam pemilihan.</p>

            <h2>8. Lakukan Voting</h2>
            <p>Setelah minting SBT, buka halaman voting di <strong>http://localhost:3000/</strong>. Pilih kandidat yang ingin Anda dukung, lalu klik tombol "VOTE". Setujui transaksi voting melalui wallet Anda.</p>
          </div>
        </div>
      </div>
    </div>
  )
}