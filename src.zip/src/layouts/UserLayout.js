import React from 'react'
import { Routes, Route } from 'react-router-dom'
import Sidebar from '../components/Common/Sidebar'
import Information from '../components/User/Information'
import Search from '../components/User/Search'
import VoteArea from '../components/User/VoteArea'
import Result from '../components/Common/Result'
import MintSBT from '../components/User/MintSBT'

const UserLayout = () => {
    return (
        <div className="flex">
            <Sidebar />
            <div className="flex-1">
                <Routes>
                    <Route path="/" element={<Information />} />
                    <Route path="search" element={<Search />} />
                    <Route path="vote-area" element={<VoteArea />} />
                    <Route path="result" element={<Result />} />
                    <Route path="mint-sbt" element={<MintSBT />} />
                </Routes>
            </div>
        </div>
    )
}

export default UserLayout
