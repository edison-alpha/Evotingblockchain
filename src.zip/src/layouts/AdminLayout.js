import React from 'react'
import { Routes, Route } from 'react-router-dom'
import Sidebar from '../components/Common/Sidebar'
import AddCandidate from '../components/Admin/AddCandidate'
import CandidateDetails from '../components/Admin/CandidateDetails'
import Voters from '../components/Admin/Voters'
import Result from '../components/Common/Result'

const AdminLayout = () => {
    return (
        <div className="flex">
            <Sidebar />
            <div className="flex-1">
                <Routes>
                    <Route path="candidate-details" element={<CandidateDetails />} />
                    <Route path="add-candidate" element={<AddCandidate />} />
                    <Route path="voters" element={<Voters />} />
                    <Route path="result" element={<Result />} />
                </Routes>
            </div>
        </div>
    )
}

export default AdminLayout
