import React, { useContext } from 'react'
import { Routes, Route, Navigate } from "react-router-dom"
import { AuthContext } from './context/AuthContext'
import Login from './components/Common/Login'
import AdminLayout from './layouts/AdminLayout'
import UserLayout from './layouts/UserLayout'

// Komponen utama aplikasi
const App = () => {
    // Mengambil data currentUser dari AuthContext
    const { currentUser, isAdmin } = useContext(AuthContext)

    const ProtectedRoute = ({ children }) => {
        if (!currentUser) {
            return <Navigate to="/login" />
        }
        return children;
    };

    return (
        <Routes>
            {/* Rute untuk halaman utama */}
            <Route path="/login" element={<Login />} />
            {/* Rute untuk halaman login */}
            <Route path="/admin/*" element={
                <ProtectedRoute>
                    {isAdmin ? <AdminLayout /> : <Navigate to="/" />}
                </ProtectedRoute>
            } />
            <Route path="/*" element={
                <ProtectedRoute>
                    <UserLayout />
                </ProtectedRoute>
            } />
        </Routes>
    )
}

export default App;
